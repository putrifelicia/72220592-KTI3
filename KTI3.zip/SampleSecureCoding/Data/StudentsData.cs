using System.Collections.Generic;
using System.Linq;
using SampleSecureCoding.Models;

namespace SampleSecureCoding.Data
{
    public class StudentsData : IStudent
    {
        private readonly DatabaseContext _db;

        public StudentsData(DatabaseContext db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public IEnumerable<Student> GetStudents()
        {
            return _db.Students.ToList();
        }

        public Student GetStudent(string nim)
        {
            return _db.Students.SingleOrDefault(s => s.Nim == nim);
        }

        public Student AddStudent(Student student)
        {
            _db.Students.Add(student);
            _db.SaveChanges();
            return student;
        }

        public Student UpdateStudent(Student student)
        {
            var existingStudent = GetStudent(student.Nim);
            if (existingStudent == null) throw new Exception("Student not found");

            existingStudent.Name = student.Name; // Update other properties as necessary
            _db.SaveChanges();
            return existingStudent;
        }

        public void DeleteStudent(string nim)
        {
            var student = GetStudent(nim);
            if (student == null) throw new Exception("Student not found");

            _db.Students.Remove(student);
            _db.SaveChanges();
        }
    }
}
