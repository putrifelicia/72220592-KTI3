using System.Collections.Generic; // Pastikan untuk mengimpor namespace ini
using SampleSecureCoding.Models;  // Impor namespace yang sesuai untuk model Student

namespace SampleSecureCoding.Data // Pastikan namespace ini sesuai
{
    public interface IStudent
    {
        /// <summary>
        /// Mengambil semua data siswa.
        /// </summary>
        /// <returns>Daftar siswa.</returns>
        IEnumerable<Student> GetStudents();

        /// <summary>
        /// Mengambil data siswa berdasarkan NIM.
        /// </summary>
        /// <param name="nim">Nomor Induk Mahasiswa siswa.</param>
        /// <returns>Objek siswa yang ditemukan.</returns>
        Student GetStudent(string nim);

        /// <summary>
        /// Menambahkan data siswa baru.
        /// </summary>
        /// <param name="student">Objek siswa yang akan ditambahkan.</param>
        /// <returns>Objek siswa yang ditambahkan.</returns>
        Student AddStudent(Student student);

        /// <summary>
        /// Memperbarui data siswa yang sudah ada.
        /// </summary>
        /// <param name="student">Objek siswa yang akan diperbarui.</param>
        /// <returns>Objek siswa yang diperbarui.</returns>
        Student UpdateStudent(Student student);

        /// <summary>
        /// Menghapus data siswa berdasarkan NIM.
        /// </summary>
        /// <param name="nim">Nomor Induk Mahasiswa siswa yang akan dihapus.</param>
        void DeleteStudent(string nim);
    }
}
