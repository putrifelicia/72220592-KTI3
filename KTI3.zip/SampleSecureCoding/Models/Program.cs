using Microsoft.EntityFrameworkCore;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    // Definisikan DbSet untuk entitas Anda
    public DbSet<Student> Students { get; set; }
    // Tambahkan DbSet lainnya sesuai kebutuhan
}