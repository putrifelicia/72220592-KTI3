using System;

namespace SampleSecureCoding.Models;

public class User
{
    public string username {get; set; } = null!;
    public string password {get; set; } = null!;
    public string userRole {get; set; } = null!;

}