using Microsoft.AspNetCore.Mvc;

namespace SampleSecureCoding.Controllers
{
    public class AccountController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
    
}