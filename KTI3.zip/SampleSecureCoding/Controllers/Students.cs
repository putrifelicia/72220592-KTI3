using System;
using Microsoft.AspNetCore.Mvc;
using SampleSecureCoding.Data;
using SampleSecureCoding.Models;

namespace SampleSecureCoding.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudent _studentData;

        // Constructor untuk meng-inject dependency IStudent
        public StudentController(IStudent studentData)
        {
            _studentData = studentData;
        }

        // Action untuk menampilkan daftar siswa
        public IActionResult Index()
        {
            var students = _studentData.GetStudents();
            return View(students);
        }

        // Action untuk menampilkan halaman pembuatan siswa baru
        public IActionResult Create()
        {
            return View();
        }

        // Action untuk menangani pengiriman form pembuatan siswa baru
        [HttpPost]
        [ValidateAntiForgeryToken] // Menambahkan token untuk keamanan
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid) // Validasi model sebelum menambah siswa
            {
                try
                {
                    _studentData.AddStudent(student);
                    return RedirectToAction(nameof(Index)); // Menggunakan nameof untuk menghindari hardcoding
                }
                catch (Exception ex)
                {
                    ViewBag.Error = ex.Message; // Menangkap error dan menampilkan pesan
                }
            }
            return View(student); // Mengembalikan view dengan model jika validasi gagal
        }
    }
}
